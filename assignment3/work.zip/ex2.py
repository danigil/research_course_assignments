import copy
import sys
from doctest import testmod
from itertools import permutations
from typing import List, Callable, Tuple
from abc import ABC

import numpy as np


class OutputType(ABC):
    @classmethod
    def output(cls, tup: Tuple):
        """
        Return the required output based on the class type
        """
        raise NotImplementedError("Choose a specific output type")


class OutputPath(OutputType):
    @classmethod
    def output(cls, path: Tuple):
        return path


class OutputPathLength(OutputType):
    @classmethod
    def output(cls, path: Tuple):
        return len(path)


def check_2d_array_structure(l):
    """
    check_2d_array_structure
    assure that l is a nxn array filled with only ints

    >>> check_2d_array_structure([[1,2,3], [4,5,6], [7,8,9]])
    True
    >>> check_2d_array_structure('this should return false')
    False
    >>> check_2d_array_structure([])
    False
    >>> check_2d_array_structure([[], 'this should return false', []])
    False
    >>> check_2d_array_structure([[1],[2],[]])
    False
    >>> check_2d_array_structure([[1],[2],['this should return false']])
    False

    """
    if isinstance(l, list) and len(l) > 0 and \
            all([isinstance(item, list) for item in l]):
        n = len(l[0])
        return all([len(item) == n for item in l]) and all([isinstance(num, int) for item in l for num in item])
    else:
        return False


"""
def brute_force_tsp(items):
    def calc_min_route(set=None):
        min_tour_cost = sys.maxsize

        if set is None:
            set = range(n)

        min_tour = tuple(set)

        for perm in permutations(set):
            current_tour_cost = 0
            for i in range(len(set) - 1):
                current_tour_cost += costs_array[perm[i]][perm[i + 1]]
            if current_tour_cost < min_tour_cost:
                min_tour_cost = current_tour_cost
                min_tour = perm
        return min_tour



    if isinstance(items, list):
        if check_2d_array_structure(items):
            # list of distances between each pair of cities
            costs_array = items
            n = len(costs_array)

            return calc_min_route()

        elif len(items) == 2 and isinstance(items[0], set) and check_2d_array_structure(items[1]):
            #  list of cities and the distances between each pair of cities
            costs_array = items[1]
            n = len(costs_array)

            return calc_min_route(items[0])


        else:
            raise Exception
    else:
        raise Exception
"""


def floyd_warshall(distance_matrix):
    if check_2d_array_structure(distance_matrix):
        n = len(distance_matrix)
        floyd = copy.deepcopy(distance_matrix)
        for i in range(n):
            floyd[n][n] = 0

        for k in range(n):
            for i in range(n):
                for j in range(n):
                    if floyd[i][j] > floyd[i][k] + floyd[k][j]:
                        floyd[i][j] = floyd[i][k] + floyd[k][j]

        return floyd
    else:
        return None
        #
        #
        # floyd = [[float('inf') for _ in range(n)] for _ in range(n)]
        # for i,j in zip(range(n),range(n)):
        #     floyd[i][j]=


def TSP(algorithm: Callable, input_items, outputtype, **kwargs):
    if isinstance(input_items, tuple):
        distance_matrix = input_items[0]
        cities_set = input_items[1]
    else:
        distance_matrix = input_items
        cities_set = range(len(input_items))

    return outputtype.output(algorithm(distance_matrix, cities_set, **kwargs))


def brute_force_tsp(items):
    pass


if __name__ == '__main__':
    # testmod(name='assignment3_ex2', verbose=True)
    # arr = [[0, 1, 10], [1, 0, 1], [10, 1, 0]]
    arr = [[0, 11, 10], [11, 0, 1], [10, 1, 0]]

    # print(brute_force_tsp(arr))
