from abc import ABC
from typing import Tuple


class OutputType(ABC):
    @classmethod
    def output(cls, tup: Tuple):
        """
        Return the required output based on the class type
        """
        raise NotImplementedError("Choose a specific output type")


class OutputPath(OutputType):
    @classmethod
    def output(cls, path: Tuple):
        return path


class OutputPathLength(OutputType):
    @classmethod
    def output(cls, path: Tuple):
        return len(path)
